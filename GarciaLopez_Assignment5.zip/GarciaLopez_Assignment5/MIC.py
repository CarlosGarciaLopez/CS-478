import keras_preprocessing
from keras_preprocessing import image
from keras_preprocessing.image import ImageDataGenerator
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import numpy as np
import tensorflow as tf
from tensorflow import keras
import keras_preprocessing
from keras_preprocessing import image
from keras_preprocessing.image import ImageDataGenerator
import sys
from datetime import date

today = date.today()

formatedDate = today.strftime("%B %d, %Y")

print("Rock, Paper and Scissors image classification server.")
print("Carlos Garcia-Lopez")
print(formatedDate)

if len(sys.argv) < 2:
    exit(0)

fileName = sys.argv[1]
new_model = tf.keras.models.load_model('model.h5')



img = image.load_img(fileName,target_size=(150,150))
x = image.img_to_array(img)
x = np.expand_dims(x,axis = 0)
images = np.vstack([x])
classes = new_model.predict(images,batch_size=10)

if classes[0][0] > 0:
    print("The image you've submitted is classified as a : paper")

elif classes[0][1] > 0:
    print("The image you've submitted is classified as a : rock")

elif classes[0][2] > 0:
    print("The image you've submitted is classified as a : scissor")


