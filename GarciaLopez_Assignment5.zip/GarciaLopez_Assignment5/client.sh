#!/bin/bash


python3 MIC.py $1
